import unittest
from unittest import TestCase
from hw02_naive_bayes_solution.naive_bayes_classifier import DataInstance,Dataset,NaiveBayesClassifier

test_inst_1 = [DataInstance.from_list_of_feature_occurrences(sample[0], sample[1]) for sample in
                [('meeting tomorrow meeting lecture'.split(' '), 'relevant'),
                 ('lecture free free free best best'.split(' '), 'promotions'),
                 ('best free hot hot hot girl girl beach'.split(' '), 'spam'),
                 ('meeting lecture morning morning'.split(' '), 'relevant'),
                 ('lecture professor work work'.split(' '), 'relevant'),
                 ('girl top free hot'.split(' '), 'spam')]]

training_inst_1 = [DataInstance.from_list_of_feature_occurrences(sample[0], sample[1]) for sample in
                [('meeting lecture'.split(' '), 'relevant'),
                 ('best lecture best'.split(' '), 'promotions'),
                 ('best hot beach'.split(' '), 'spam'),
                 ('tomorrow document'.split(' '), 'relevant'),
                 ('work'.split(' '), 'relevant'),
                 ('cream girl beach'.split(' '), 'promotions')]]

training_inst_2 = [DataInstance.from_list_of_feature_occurrences(sample[0], sample[1]) for sample in
                [('meeting lecture'.split(' '), 'relevant'),
                 ('best lecture best'.split(' '), 'promotions'),
                 ('best hot beach'.split(' '), 'spam'),
                 ('tomorrow meeting document document document document document'.split(' '), 'relevant'),
                 ('cream girl beach'.split(' '), 'promotions')]]

class NaiveBayesTest(TestCase):

    def setUp(self):
        self.data_set_1 = Dataset(training_inst_1)
        self.data_set_2 = Dataset(test_inst_1)
        self.data_set_3 = Dataset(training_inst_2)
        self.nbc = NaiveBayesClassifier.for_dataset(self.data_set_1, smoothing = 1.0)
        self.nbc_2 = NaiveBayesClassifier.for_dataset(self.data_set_3, smoothing = 1.0)
        
    def test01_from_list_of_feature_occurrences_02(self):
        """Checking if Data instance is created correctly"""
        feature_list= ['house','free','buy', 'house', 'buy', 'sale']
        label = 'spam'
        instance = DataInstance.from_list_of_feature_occurrences(feature_list,label)
        self.assertEqual(instance.label,label)
        self.assertEqual(instance.feature_counts,{'buy':2,'house':2,'free':1, 'sale':1})

    def test02_for_dataset_02(self):
        """Checking if a NaiveBayesClassifier is constructed correctly for a dataset."""
        self.assertEqual(self.nbc.word_and_cat_to_count,{('girl', 'promotions'): 1, ('meeting', 'relevant'): 1, ('cream', 'promotions'): 1, ('beach', 'promotions'): 1, ('hot', 'spam'): 1, \
                                                         ('best', 'spam'): 1, ('work', 'relevant'): 1, ('document', 'relevant'): 1, ('lecture', 'relevant'): 1, ('tomorrow', 'relevant'): 1, \
                                                         ('best', 'promotions'): 2, ('lecture', 'promotions'): 1, ('beach', 'spam'): 1})
        self.assertEqual(self.nbc.cat_to_num_words, {'spam': 3, 'promotions': 6, 'relevant': 5})
        self.assertEqual(self.nbc.vocabsize, 10)
        self.assertAlmostEqual(self.nbc.category_to_prior['spam'],0.1666666666)
        self.assertAlmostEqual(self.nbc.category_to_prior['relevant'] , 0.5)
        self.assertAlmostEqual(self.nbc.category_to_prior['promotions'] , 0.333333333)
        self.assertEqual(self.nbc.smoothing, 1.0)
        
    def test03_prediction_02(self):
        """Checking if the class 'string' was correctly predicted"""
        self.assertEqual([self.nbc.prediction(inst.feature_counts) for inst in self.data_set_2.instance_list],['relevant', 'promotions', 'spam', 'relevant', 'relevant', 'spam'])
        
    def test04_prediction_accuracy_02(self):
        """Checking if the prediction accuracy of the classifier is correct"""
        self.assertAlmostEqual(self.nbc.prediction_accuracy(self.data_set_2),1.0)
        
    def test05_log_odds_for_word_02(self):
        """Checking if log-odds value of each word is computed correctly"""
        self.assertAlmostEqual(self.nbc.log_odds_for_word('lecture', 'relevant'), 0.20173964265)
        self.assertAlmostEqual(self.nbc.log_odds_for_word('free', 'spam'), -1.44101926)
		
    def test06_features_for_category_02(self):
        """Checking if the words with the highest log-odds are retrieved correctly"""
        self.assertEqual(self.nbc_2.features_for_category("relevant"),['document', 'meeting', 'tomorrow', 'lecture'])