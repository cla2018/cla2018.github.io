from unittest import TestCase
from hw08_entity_types import utils
from hw08_entity_types.predict_types import train_evaluate_type_prediction
import numpy as np


class TestEntitiesTypesHidden(TestCase):

    # Exercise 1
    def test_01_read_word_vectors(self):
        """ Tests if word vectors are read correctly."""
        vec_file = "hw08_entity_types/unittest-toydata/word_vectors_hidden.txt"
        m, w2id = utils.read_word2vec_file(vec_file)
        self.assertIsInstance(m, np.ndarray)
        self.assertEqual(w2id, {'fries': 1, 'germany': 0})
        m_expected = np.array([[1, 2, 0, 4, 0, 0.3],
                               [0.1, 0.2, 0.8, 0, 0.7, 0.5]])
        self.assertEqual(m.tolist(), m_expected.tolist())

    # Exercise 2
    def test_02_read_entity_types_file(self):
        """ Tests if train files are read correctly."""
        vec_file = "hw08_entity_types/unittest-toydata/word_vectors_hidden.txt"
        entities_file = "hw08_entity_types/unittest-toydata/entity_types_hidden.txt"
        m, w2id = utils.read_word2vec_file(vec_file)
        x, y, type_to_id = utils.read_entity_types_file(entities_file, m, w2id)
        self.assertEqual(x.shape, (4, 6))
        self.assertEqual(y.shape, (4, 3))
        self.assertTrue((x[0] == [0] * 6).all())
        self.assertTrue((x[3] == [0] * 6).all())
        self.assertEqual(set(type_to_id.keys()), {'food', 'location', 'animal'})
        self.assertEqual(len(type_to_id.values()), 3)

    # Exercise 3
    def test_03_predict_evaluate(self):
        """ Tests if classification and F1 score are computed correctly."""
        vec_file = "hw08_entity_types/unittest-toydata/word_vectors_hidden.txt"
        train_file = "hw08_entity_types/unittest-toydata/entity_types_hidden.txt"
        test_file = "hw08_entity_types/unittest-toydata/entity_types_hidden.txt"

        prec, rec, f_score = train_evaluate_type_prediction(vec_file, train_file, test_file)
        self.assertAlmostEqual(prec, 1.0, delta=0.01)
        self.assertAlmostEqual(rec, 0.5, delta=0.01)
        self.assertAlmostEqual(f_score, 0.66, delta=0.01)
